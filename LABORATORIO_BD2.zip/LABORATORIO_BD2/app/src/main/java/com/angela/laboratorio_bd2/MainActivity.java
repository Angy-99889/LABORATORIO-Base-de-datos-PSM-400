package com.angela.laboratorio_bd2;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText et_codigo, et_nombre, et_carrera, et_edad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_codigo = findViewById(R.id.txt_codigo);
        et_nombre = findViewById(R.id.txt_nombre);
        et_carrera = findViewById(R.id.txt_carrera);
        et_edad = findViewById(R.id.txt_edad);
    }

    public void Registrar(View view) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();

        String codigo = et_codigo.getText().toString();
        String nombre = et_nombre.getText().toString();
        String carrera = et_carrera.getText().toString();
        String edad = et_edad.getText().toString();

        if (!codigo.isEmpty() && !nombre.isEmpty() && !carrera.isEmpty() && !edad.isEmpty()) {
            ContentValues registro = new ContentValues();
            registro.put("codigo", codigo);
            registro.put("nombre", nombre);
            registro.put("carrera", carrera);
            registro.put("edad", edad);

            bd.insert("estudiantes", null, registro);
            bd.close();

            et_codigo.setText("");
            et_nombre.setText("");
            et_carrera.setText("");
            et_edad.setText("");

            Toast.makeText(this, "Estudiante registrado correctamente", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Debes llenar todos los campos", Toast.LENGTH_SHORT).show();
        }
    }

    public void Buscar(View view) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getReadableDatabase();
        String codigo = et_codigo.getText().toString();

        if (!codigo.isEmpty()) {
            Cursor fila = bd.rawQuery("SELECT nombre, carrera, edad FROM estudiantes WHERE codigo=" + codigo, null);
            if (fila.moveToFirst()) {
                et_nombre.setText(fila.getString(0));
                et_carrera.setText(fila.getString(1));
                et_edad.setText(fila.getString(2));
            } else {
                Toast.makeText(this, "No existe el estudiante", Toast.LENGTH_SHORT).show();
            }
            fila.close();
            bd.close();
        } else {
            Toast.makeText(this, "Debes introducir el código del estudiante", Toast.LENGTH_SHORT).show();
        }
    }

    public void Eliminar(View view) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String codigo = et_codigo.getText().toString();

        if (!codigo.isEmpty()) {
            int cantidad = bd.delete("estudiantes", "codigo=" + codigo, null);
            bd.close();

            et_codigo.setText("");
            et_nombre.setText("");
            et_carrera.setText("");
            et_edad.setText("");

            if (cantidad == 1) {
                Toast.makeText(this, "Estudiante eliminado correctamente", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "El estudiante no existe", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Debes introducir el código del estudiante", Toast.LENGTH_SHORT).show();
        }
    }

    public void Modificar(View view) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String codigo = et_codigo.getText().toString();
        String nombre = et_nombre.getText().toString();
        String carrera = et_carrera.getText().toString();
        String edad = et_edad.getText().toString();

        if (!codigo.isEmpty() && !nombre.isEmpty() && !carrera.isEmpty() && !edad.isEmpty()) {
            ContentValues registro = new ContentValues();
            registro.put("nombre", nombre);
            registro.put("carrera", carrera);
            registro.put("edad", edad);

            int cantidad = bd.update("estudiantes", registro, "codigo=" + codigo, null);
            bd.close();

            if (cantidad == 1) {
                Toast.makeText(this, "Estudiante modificado correctamente", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "El estudiante no existe", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Debes llenar todos los campos", Toast.LENGTH_SHORT).show();
        }
    }
}