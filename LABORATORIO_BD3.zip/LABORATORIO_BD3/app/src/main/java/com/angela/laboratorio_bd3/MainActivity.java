package com.angela.laboratorio_bd3;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText et_codigo, et_marca, et_modelo, et_color, et_anio, et_precio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_codigo = findViewById(R.id.txt_codigo);
        et_marca = findViewById(R.id.txt_marca);
        et_modelo = findViewById(R.id.txt_modelo);
        et_color = findViewById(R.id.txt_color);
        et_anio = findViewById(R.id.txt_anio);
        et_precio = findViewById(R.id.txt_precio);
    }

    // Registrar automóvil
    public void Registrar(View view) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();

        String codigo = et_codigo.getText().toString();
        String marca = et_marca.getText().toString();
        String modelo = et_modelo.getText().toString();
        String color = et_color.getText().toString();
        String anio = et_anio.getText().toString();
        String precio = et_precio.getText().toString();

        if (!codigo.isEmpty() && !marca.isEmpty() && !modelo.isEmpty() && !color.isEmpty() && !anio.isEmpty() && !precio.isEmpty()) {
            ContentValues registro = new ContentValues();
            registro.put("codigo", codigo);
            registro.put("marca", marca);
            registro.put("modelo", modelo);
            registro.put("color", color);
            registro.put("anio", anio);
            registro.put("precio", precio);

            bd.insert("automoviles", null, registro);
            bd.close();

            et_codigo.setText("");
            et_marca.setText("");
            et_modelo.setText("");
            et_color.setText("");
            et_anio.setText("");
            et_precio.setText("");

            Toast.makeText(this, "Automóvil registrado correctamente", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Debes llenar todos los campos", Toast.LENGTH_SHORT).show();
        }
    }

    // Buscar automóvil
    public void Buscar(View view) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getReadableDatabase();
        String codigo = et_codigo.getText().toString();

        if (!codigo.isEmpty()) {
            Cursor fila = bd.rawQuery("SELECT marca, modelo, color, anio, precio FROM automoviles WHERE codigo=" + codigo, null);
            if (fila.moveToFirst()) {
                et_marca.setText(fila.getString(0));
                et_modelo.setText(fila.getString(1));
                et_color.setText(fila.getString(2));
                et_anio.setText(fila.getString(3));
                et_precio.setText(fila.getString(4));
            } else {
                Toast.makeText(this, "No existe el automóvil", Toast.LENGTH_SHORT).show();
            }
            fila.close();
            bd.close();
        } else {
            Toast.makeText(this, "Debes introducir el código del automóvil", Toast.LENGTH_SHORT).show();
        }
    }

    // Eliminar automóvil
    public void Eliminar(View view) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String codigo = et_codigo.getText().toString();

        if (!codigo.isEmpty()) {
            int cantidad = bd.delete("automoviles", "codigo=" + codigo, null);
            bd.close();
            et_codigo.setText("");
            et_marca.setText("");
            et_modelo.setText("");
            et_color.setText("");
            et_anio.setText("");
            et_precio.setText("");

            if (cantidad == 1) {
                Toast.makeText(this, "Automóvil eliminado correctamente", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "El automóvil no existe", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Debes introducir el código del automóvil", Toast.LENGTH_SHORT).show();
        }
    }

    // Modificar automóvil
    public void Modificar(View view) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();

        String codigo = et_codigo.getText().toString();
        String marca = et_marca.getText().toString();
        String modelo = et_modelo.getText().toString();
        String color = et_color.getText().toString();
        String anio = et_anio.getText().toString();
        String precio = et_precio.getText().toString();

        if (!codigo.isEmpty() && !marca.isEmpty() && !modelo.isEmpty() && !color.isEmpty() && !anio.isEmpty() && !precio.isEmpty()) {
            ContentValues registro = new ContentValues();
            registro.put("marca", marca);
            registro.put("modelo", modelo);
            registro.put("color", color);
            registro.put("anio", anio);
            registro.put("precio", precio);

            int cantidad = bd.update("automoviles", registro, "codigo=" + codigo, null);
            bd.close();

            if (cantidad == 1) {
                Toast.makeText(this, "Automóvil modificado correctamente", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "El automóvil no existe", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Debes llenar todos los campos", Toast.LENGTH_SHORT).show();
        }
    }
}